========================================
   Cleaner Web - Créé par xxwfufu 🧼
========================================

Ce projet sert à nettoyer ton ordinateur facilement grâce à une interface simple.

LANCE LES FICHIERS DANS CET ORDRE :

1. 01_create_venv.bat
2. 02_install_requirements.bat
3. 03_create_script.bat
4. 04_build_exe.bat
5. 05_launch_cleaner.bat

IMPORTANT :
Nettoyer son ordinateur permet :
- d’améliorer ses performances 💨
- de libérer de l’espace disque 🧹
- de prolonger la durée de vie 🖥️

by xxwfufu
